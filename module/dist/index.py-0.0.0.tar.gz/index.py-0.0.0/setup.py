# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 09:44:00 2019

@author: Yohannes Assebe
"""
from distutils.core import setup
setup(
 name="index.py",
 author="Yohannes Assebe",
 author_email="JohnAssebe@gmail.com",
 url="www.JohnAssebeProjects.com",
 )
